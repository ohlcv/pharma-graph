---
data:
  id: direct-dna-acting-antitumor
  label: 直接影响DNA结构和功能的药物
  essence: module
  field: pharmacology
  tier: management
  location:
    book: 药学专业知识二
    chapter: 第十章 抗肿瘤药
    section: 第一节 直接影响DNA结构和功能的药物
  tags:
    - 烷化剂
    - 铂类
    - 顺铂
    - 拓扑异构酶抑制剂
    - 细胞毒
    - 化疗
  summary:
    short: 铂类药物是化疗的基石，烷化剂和拓扑酶抑制剂各有绝活。
    full: 这类药直接破坏肿瘤细胞的DNA。铂类（顺铂、卡铂、奥沙利铂）是化疗的"老大哥"，几乎所有实体瘤都可能用到，但有肾毒性和耳毒性。烷化剂（环磷酰胺）用得也很多，但可能导致出血性膀胱炎。拓扑异构酶抑制剂（伊立替康、依托泊苷）是后起之秀。
  edges_out:
    - target: antitumor-drugs-y2
      type: isa
      reason: 本节属于抗肿瘤药章
    - target: antimetabolite-antitumor
      type: prerequisite
      reason: 理解DNA损伤是细胞毒化疗的基础
    - target: hematologic-drugs-y2
      type: prerequisite
      reason: 骨髓抑制是这类药的主要毒性
    - target: tumor-chemotherapy-management
      type: relates
      reason: DNA损伤药用于肿瘤化疗
---

# 直接影响DNA结构和功能的药物


## 这是什么药？

这是化疗药里的"重武器"，直接攻击肿瘤细胞的DNA。铂类（顺铂、卡铂、奥沙利铂）是三大铂药，顺铂肾毒性最重，卡铂骨髓抑制最重，奥沙利铂相对温和主要用于肠癌。烷化剂（环磷酰胺）用得也很广，但有个讨厌的副作用——出血性膀胱炎，要配合美司钠预防。

## 为什么要知道它？

因为这类药毒性很大，临床上需要仔细监测。顺铂伤肾、博来霉素伤肺、蒽环类伤心脏——每个药都有自己的"雷区"。药师要帮助医生和患者管理这些毒性，该水化的时候水化，该停药的时候停药。

## 它和什么有关？

它和血液系统用药有关——骨髓抑制是最常见的毒性，白细胞低了要打升白针。它和营养支持也有关——化疗期间恶心呕吐很常见，需要预防性用止吐药。

## 一般在什么时候用？

确诊恶性肿瘤、需要化疗的时候用。学到这里，重点是记住：细胞毒化疗是"伤敌一千自损八百"，平衡疗效和毒性是临床决策的核心。

## 在药学知识体系里算什么？

它是化疗药的"经典流派"，往后还有靶向药、免疫治疗，毒性管理的思路是一脉相承的。
