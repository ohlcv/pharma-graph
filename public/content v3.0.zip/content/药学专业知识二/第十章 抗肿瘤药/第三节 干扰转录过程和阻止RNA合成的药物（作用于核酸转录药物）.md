---
data:
  id: sec-rna-drug-y2-10-03
  label: 第三节 干扰转录过程和阻止RNA合成的药物（作用于核酸转录药物）
  essence: module
  location:
    book: 药学专业知识二
    chapter: 第十章 抗肿瘤药
    section: 第三节 干扰转录过程和阻止RNA合成的药物（作用于核酸转录药物）
  edges_out:
    - target: ch-oncology-y2-10
      type: part_of
      reason: 属于该章
  fill: cls-structure
---
